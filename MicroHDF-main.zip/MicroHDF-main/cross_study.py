"""
    cross-study validation experiments
    method include: MicroHDF, MLPNN, CNN1D, RF, SVM, LASSO
    including: 4 study, two diseases: IBD (IBD: two class balance datasets and two imbalance datasets)
                                      ASD (ASD: two class balance datasets and two imbalance datasets)
"""
from gcForest import gcForest
from logger import get_logger
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split,StratifiedKFold,RepeatedStratifiedKFold, KFold
import numpy as np
import tensorflow as tf
import pandas as pd
import pickle
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.ensemble import RandomForestClassifier,ExtraTreesClassifier,AdaBoostClassifier,BaggingClassifier,GradientBoostingClassifier
from imblearn.under_sampling import RandomUnderSampler
from imblearn.ensemble import BalancedBaggingClassifier, BalancedRandomForestClassifier
from collections import Counter
# from ERTs import ExtraTreesClassifier
from evaluation import accuracy,f1_binary,f1_macro,f1_micro, auc_scores
# from load_data import load_data
from test_load_data import test_load_data
# from feature_selection import select_feature
from feature_selection_test import feature_select
# from feature_selection_test import calc_f3
from sklearn.metrics import average_precision_score,matthews_corrcoef,f1_score,recall_score,confusion_matrix,classification_report,roc_auc_score,auc,precision_recall_curve,accuracy_score,classification_report, roc_curve
from imblearn.ensemble import BalancedBaggingClassifier,RUSBoostClassifier,BalancedRandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import SelectFromModel
from sklearn.linear_model import LassoCV, Lasso
from sklearn.multiclass import OneVsRestClassifier
from sklearn.preprocessing import MinMaxScaler, StandardScaler, label_binarize
# from imblearn.metrics import geometric_mean_scor
import matplotlib.pyplot as plt


# our model
def get_config():
    config = {}
    config["random_state"] = None
    config["max_layers"] = 100
    config["early_stop_rounds"] = 5
    config["if_stacking"] = False
    config["if_save_model"] = False
    # f1_binary,f1_macro,f1_micro,accuracy
    config["train_evaluation"] = f1_macro
    config["estimator_configs"] = []
    config["estimator_configs"].append({"n_fold": 5, "type": "RandomForestClassifier", "n_estimators": 100, "n_jobs": -1, "min_impurity_decrease": 1e-7})
    config["estimator_configs"].append({"n_fold": 5, "type": "RandomForestClassifier", "n_estimators": 100, "n_jobs": -1, "min_impurity_decrease": 1e-7})
    # config["estimator_configs"].append({"n_fold":10,"type":"ExtraTreesClassifier","n_estimators":100,"n_jobs":-1, "min_impurity_decrease": 1e-7})
    config["estimator_configs"].append({"n_fold": 5, "type": "ExtraTreesClassifier", "n_estimators": 100, "n_jobs": -1,"min_impurity_decrease": 1e-7})
    config["estimator_configs"].append({"n_fold": 5, "type": "ExtraTreesClassifier", "n_estimators": 100, "n_jobs": -1,"min_impurity_decrease": 1e-7})
    config["output_layer_config"] = []
    # ExtraTreesClassifier
    return config


"""
if __name__ == "__main__":
    config = get_config()
    skf = RepeatedStratifiedKFold(n_splits=5, random_state=0, n_repeats=1)

    accuracys = []
    aucs = []
    f1s = []
    auprs = []
    mccs = []
    recalls = []
    gmeans = []
    i = 1
    fpr = np.linspace(0, 1, 101)
    tpr = np.zeros_like(fpr)
    fpr_tpr = []

    x_train_val, y_train_val, _ = test_load_data(dataid=13)

    x_test_val, y_test_val, _ = test_load_data(dataid=14)
    print("Size of x_val:", x_test_val.shape)
    print("Size of y_val:", y_test_val.shape)
    min_samples = min(len(x_train_val), len(x_test_val))
    if len(x_train_val) > min_samples:
        x_train_val, _, y_train_val, _ = train_test_split(x_train_val, y_train_val, train_size=min_samples, random_state=42)
    if len(x_test_val) > min_samples:
        x_test_val, _, y_test_val, _ = train_test_split(x_test_val, y_test_val, train_size=min_samples, random_state=42)
    for train_id, test_id in skf.split(x_train_val, y_train_val):
        print("============{}-th cross validation============".format(i))

        if len(test_id) < 5:
            print("Skip this fold because of insufficient test samples")
            continue
        # print("Shape of x_train_val:", x_train_val.shape)
        # print("Shape of y_train_val:", y_train_val.shape)
        # print("Shape of x_test_val:", x_test_val.shape)
        # print("Shape of y_test_val:", y_test_val.shape)
        # print("Number of splits:", skf.get_n_splits(x_train_val, y_train_val))
        x_train, x_test, y_train, y_test = x_train_val[train_id], x_test_val[test_id], y_train_val[train_id], y_test_val[test_id]
        index = feature_select(x_train, y_train, 180, 180)
        index_1 = feature_select(x_test, y_test, 180, 180)
        x_train = x_train[:, index]
        x_test = x_test[:, index_1]
        # print("Shape of x_test after indexing:", x_test.shape)
        config = get_config()
        gc = gcForest(config)
        rf = RandomForestClassifier()
        gc.fit(x_train, y_train)
        # calculate y_score
        y_pred = gc.predict(x_test)
        y_pred_prob = gc.predict_proba(x_test)
        # plot ROC curve
        y_score = []
        for item in y_pred_prob:
            y_score.append(item[1])
        y_score = np.array(y_score)
        precision, recall, thresholds = precision_recall_curve(y_test, y_score, pos_label=2)
        aupr = auc(recall, precision)
        # 计算TPR和FPR
        fpr, tpr, _ = roc_curve(y_test, y_score, pos_label=1)
        roc_auc = auc(fpr, tpr)

        data = {'False Positive Rate': fpr, 'True Positive Rate': tpr}
        df = pd.DataFrame(data)
        df.to_csv('roc_data.csv', index=False)

        accuracy = accuracy_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred, average='binary')
        recall = recall_score(y_test, y_pred, average="binary")
        # mcc = matthews_corrcoef(y_test, y_pred)
        # gmean = geometric_mean_score(y_test, y_pred, average='binary')
        auc_s = auc_scores(y_test, y_pred_prob[:, 1])

        f1s.append(f1)
        accuracys.append(accuracy)
        aucs.append(auc_s)
        auprs.append(aupr)
        recalls.append(recall)
        # mccs.append(mcc)
        # gmeans.append(gmean)
        i += 1

    print("============training finished============")
    f1s = np.array(f1s)
    auprs = np.array(auprs)
    recalls = np.array(recalls)
    # mccs = np.array(mccs)
    # gmeans = np.array(gmeans)

    print("Model: Micro_DF")
    print("accuracy average:", np.mean(accuracys))
    print("auc average:", np.mean(aucs))
    print("f1 average:", np.mean(f1s))
    print("aupr average:", np.mean(auprs))
    print("recall average:", np.mean(recalls))
    # print("mcc average:", np.mean(mccs))
    # print("gmean average:", np.mean(gmeans))

"""

class MLPNN():
    def __init__(self, input_len, num_class):
        num_fc_nodes = 32
        num_fc_layers = 2
        lamb = 0.001
        drop = 0.3

        reg = tf.keras.regularizers.l2(lamb)
        self.model = tf.keras.Sequential()

        self.model.add(tf.keras.layers.GaussianNoise(0.01, input_shape=(input_len,)))

        for i in range(0, num_fc_layers):
            self.model.add(tf.keras.layers.Dense(num_fc_nodes, activation='relu', kernel_regularizer=reg, bias_regularizer=reg, name="fc_"+str(i)))
            self.model.add(tf.keras.layers.Dropout(drop))

        self.model.add(tf.keras.layers.Dense(num_class, activation='softmax', kernel_regularizer=reg, bias_regularizer=reg, name="output"))

        self.patience = 0.001
        self.learning_rate = 0.001
        self.batch_size = 1024

    def train(self, train):
        train_x, train_y = train

        def auc_metric(y_true, y_pred):
            return tf.numpy_function(roc_auc_score, (y_true, y_pred), tf.double)

        self.model.compile(optimizer=tf.keras.optimizers.Adam(self.learning_rate), loss='categorical_crossentropy',
                           metrics=[auc_metric])

        if len(np.unique(train_y) == 2):
            es_cb = tf.keras.callbacks.EarlyStopping('val_loss', patience=self.patience)
        else:
            es_cb = tf.keras.callbacks.EarlyStopping('val_loss', patience=self.patience)

        return

    def test(self, test):
        test_x, test_y = test

        preds = self.model.predict(test_x)
        # stats = get_stat_dict(test_y, preds)
        return preds

    def predict_proba(self, test):
        test_x = test

        preds = self.model.predict(test_x)
        return preds

    def destroy(self):
        tf.keras.backend.clear_session()
        return

# define CNN
class CNN1D():

    def __init__(self, input_len, num_class):
        num_kernel = 16
        kernel_height = 1
        kernel_width = 10
        num_fc_nodes = 32
        num_cnn_layers = 2
        num_fc_layers = 2
        lamb = 0.001
        drop = 0.3

        reg = tf.keras.regularizers.l2(lamb)
        self.model = tf.keras.Sequential()

        self.model.add(tf.keras.layers.GaussianNoise(0.01, input_shape=(1, input_len, 1)))

        for i in range(0, num_cnn_layers):
            self.model.add(tf.keras.layers.Conv2D(filters=num_kernel, kernel_size=(kernel_height, kernel_width),
                                                  activation='relu', bias_regularizer=reg, kernel_regularizer=reg,
                                                  name="conv_" + str(i)))
            self.model.add(tf.keras.layers.MaxPooling2D(pool_size=(1, 2)))

        self.model.add(tf.keras.layers.Flatten())
        self.model.add(tf.keras.layers.Dropout(drop))

        for i in range(0, num_fc_layers):
            self.model.add(
                tf.keras.layers.Dense(num_fc_nodes, activation='relu', kernel_regularizer=reg, bias_regularizer=reg,
                                      name="fc_" + str(i)))
            self.model.add(tf.keras.layers.Dropout(drop))

        self.model.add(
            tf.keras.layers.Dense(num_class, activation='softmax', kernel_regularizer=reg, bias_regularizer=reg,
                                  name="output"))

        self.patience = 40
        self.learning_rate = 0.001
        self.batch_size = 1024

    def train(self, train):
        train_x, train_y = train
        train_x = np.expand_dims(train_x, -1)
        train_x = np.expand_dims(train_x, 1)

        def mcc_metric(y_true, y_pred):
            predicted = tf.cast(tf.greater(y_pred, 0.5), tf.float32)
            true_pos = tf.math.count_nonzero(predicted * y_true)
            true_neg = tf.math.count_nonzero((predicted - 1) * (y_true - 1))
            false_pos = tf.math.count_nonzero(predicted * (y_true - 1))
            false_neg = tf.math.count_nonzero((predicted - 1) * y_true)
            x = tf.cast(
                (true_pos + false_pos) * (true_pos + false_neg) * (true_neg + false_pos) * (true_neg + false_neg),
                tf.float32)
            return tf.cast((true_pos * true_neg) - (false_pos * false_neg), tf.float32) / tf.sqrt(x)

        def auc_metric(y_true, y_pred):
            return tf.numpy_function(roc_auc_score, (y_true, y_pred), tf.double)

        self.model.compile(optimizer=tf.keras.optimizers.Adam(self.learning_rate), loss='categorical_crossentropy',
                           metrics=[auc_metric, mcc_metric])

        if len(np.unique(train_y) == 2):
            es_cb = tf.keras.callbacks.EarlyStopping('val_loss', patience=self.patience)
        else:
            es_cb = tf.keras.callbacks.EarlyStopping('val_loss', patience=self.patience)

        return

    def test(self, test):
        test_x, test_y = test
        test_x = np.expand_dims(test_x, -1)
        test_x = np.expand_dims(test_x, 1)

        preds = self.model.predict(test_x)
        return preds

    def predict_proba(self, test):
        test_x = test
        test_x = np.expand_dims(test_x, -1)
        test_x = np.expand_dims(test_x, 1)
        preds = self.model.predict(test_x)
        return preds

    def destroy(self):
        tf.keras.backend.clear_session()
        return

# define LASSO
class LASSO():

    def __init__(self):
        self.max_iter = 1000
        self.num_cv = 5
        self.num_class = 2
        if self.num_class > 2:
            self.model = OneVsRestClassifier(LassoCV(alphas=np.logspace(-4, -0.5, 50),
                                                     cv=self.num_cv, n_jobs=-1, max_iter=self.max_iter))
        else:
            self.model = LassoCV(alphas=np.logspace(-4, -0.5, 50), cv=self.num_cv, n_jobs=-1, max_iter=self.max_iter)

    def train(self, train):
        x, y = train
        self.model.fit(x, y)
        return

    def test(self, test):
        x, y = test

        probs = np.array([[1 - row, row] for row in self.model.predict(x)])
        preds = np.argmax(probs, axis=-1)
        return preds

    def predict_proba(self, test):
        test_x = test
        preds = self.model.predict(test_x)
        return preds

if __name__ == "__main__":
    skf = RepeatedStratifiedKFold(n_splits=5, random_state=0, n_repeats=1)

    accuracys = []
    aucs = []
    f1s = []
    auprs = []
    mccs = []
    recalls = []
    gmeans = []
    i = 1
    fpr = np.linspace(0, 1, 101)
    tpr = np.zeros_like(fpr)
    fpr_tpr = []

    # dataload train dataset
    x_train_val, y_train_val, _ = test_load_data(dataid=10)

    # dataload test dataset
    x_test_val, y_test_val, _ = test_load_data(dataid=11)
    print("Size of x_val:", x_test_val.shape)
    print("Size of y_val:", y_test_val.shape)
    min_samples = min(len(x_train_val), len(x_test_val))
    if len(x_train_val) > min_samples:
        x_train_val, _, y_train_val, _ = train_test_split(x_train_val, y_train_val, train_size=min_samples, random_state=42)
    if len(x_test_val) > min_samples:
        x_test_val, _, y_test_val, _ = train_test_split(x_test_val, y_test_val, train_size=min_samples, random_state=42)
    for train_id, test_id in skf.split(x_train_val, y_train_val):
        print("============{}-th cross study validation============".format(i))

        if len(test_id) < 5:
            print("Skip this fold because of insufficient test samples")
            continue
        x_train, x_test, y_train, y_test = x_train_val[train_id], x_test_val[test_id], y_train_val[train_id], y_test_val[test_id]
        index = feature_select(x_train, y_train, 80, 120)
        index_1 = feature_select(x_test, y_test, 80, 120)
        x_train = x_train[:, index]
        x_test = x_test[:, index_1]
        # print("Shape of x_test after indexing:", x_test.shape)

        config = get_config()
        gc = gcForest(config)
        rf = RandomForestClassifier()
        gc.fit(x_train, y_train)
        # calculate y_score
        y_pred = gc.predict(x_test)
        y_pred_prob = gc.predict_proba(x_test)


        # # SVM LASSO 需要做特征缩放
        # scaler = StandardScaler()
        # x_train = scaler.fit_transform(x_train)
        # x_test = scaler.transform(x_test)
        # svm = SVC(probability=True)
        # rf = RandomForestClassifier()
        # rf.fit(x_train, y_train)
        # y_pred = rf.predict(x_test)
        # y_pred_prob = rf.predict_proba(x_test)

        #
        # svm.fit(x_train, y_train)
        # # calculate y_score
        # y_pred = svm.predict(x_test)
        # y_pred_prob = svm.predict_proba(x_test)

        # lasso = LASSO()
        # lasso.train((x_train, y_train))
        # y_pred = lasso.test((x_test, y_test))
        # y_pred_prob = lasso.predict_proba(x_test)
        # print(y_pred_prob)

        # # MLPNN
        # mlpnn = MLPNN(input_len=x_train.shape[1], num_class=2)
        # mlpnn.train((x_train, y_train))
        # y_pred = np.argmax(mlpnn.test((x_test, y_test)), axis=1)
        # y_pred_prob = mlpnn.predict_proba(x_test)

        # cnn = CNN1D(input_len=x_train.shape[1], num_class=2)
        # cnn.train((x_train, y_train))
        # y_pred = np.argmax(cnn.test((x_test, y_test)), axis=1)
        # y_pred_prob = cnn.predict_proba(x_test)

        # plot ROC curve
        if y_pred_prob.shape[1] == 1:
            y_score = np.zeros_like(y_pred_prob[:, 0])
        else:
            y_score = y_pred_prob[:, 1]

        # y_score = []
        # for item in y_pred_prob:
        #     y_score.append(item[1])

        # y_score = y_pred_prob   # LASSO
        y_score = np.array(y_score)
        precision, recall, thresholds = precision_recall_curve(y_test, y_score, pos_label=2)
        aupr = auc(recall, precision)
        # 计算TPR和FPR
        fpr, tpr, _ = roc_curve(y_test, y_score, pos_label=1)
        roc_auc = auc(fpr, tpr)

        data = {'FPR': fpr, 'TPR': tpr}
        df = pd.DataFrame(data)
        df.to_csv('roc_data.csv', index=False)

        accuracy = accuracy_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred, average='macro')
        recall = recall_score(y_test, y_pred, average="macro")
        mcc = matthews_corrcoef(y_test, y_pred)
        # gmean = geometric_mean_score(y_test, y_pred, average='binary')
        # auc_s = auc_scores(y_test, y_pred_prob[:, 1])
        if y_pred_prob.shape[1] == 1:
            auc_s = 0.5
        else:
            auc_s = roc_auc

        # auc_s = auc_scores(y_test, y_pred_prob) # LASSO

        f1s.append(f1)
        accuracys.append(accuracy)
        aucs.append(auc_s)
        auprs.append(aupr)
        recalls.append(recall)
        i += 1

    print("============training finished============")
    f1s = np.array(f1s)
    auprs = np.array(auprs)
    recalls = np.array(recalls)


    print("accuracy average:", np.mean(accuracys))
    print("auc average:", np.mean(aucs))
    print("f1 average:", np.mean(f1s))
    print("aupr average:", np.mean(auprs))
    print("recall average:", np.mean(recalls))


