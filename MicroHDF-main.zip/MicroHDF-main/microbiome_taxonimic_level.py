import pandas as pd
df = pd.read_csv('./tax_process/abundance_T2D.csv', sep=',')
sample_ids = df.iloc[:, 0]
features = df.columns[1:]

def merge_to_level(level, level_prefix):
    merged_data = {}

    for feature in features:
        levels = feature.split('|')

        if any(level_prefix in level for level in levels):
            target_level = "|".join(levels[:level])
        else:
            target_level = feature

        if target_level not in merged_data:
            merged_data[target_level] = df[feature].copy()
        else:
            merged_data[target_level] += df[feature]

    merged_df = pd.DataFrame(merged_data)
    merged_df.insert(0, 'SampleID', sample_ids)

    return merged_df


level_mapping = {
    'genus': (6, 'g__'),  #  g__
    'family': (5, 'f__'),  #  f__
    'order': (4, 'o__'),  #  o__
    'class': (3, 'c__'),  #  c__
    'phylum': (2, 'p__')  #  p__
}

for level_name, (level, level_prefix) in level_mapping.items():
    merged_df = merge_to_level(level, level_prefix)
    file_path = f'./tax_process/T2D_{level_name}_abundance.csv'
    merged_df.to_csv(file_path, index=False)
    print(f"Data has been successfully processed and saved to '{file_path}'")

print("All data levels have been successfully processed and saved.")