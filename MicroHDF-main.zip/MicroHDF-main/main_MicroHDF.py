from gcForest import gcForest
from logger import get_logger
import numpy as np
import pandas as pd
import pickle
from sklearn.model_selection import train_test_split,StratifiedKFold,RepeatedStratifiedKFold, KFold
from sklearn.ensemble import RandomForestClassifier,ExtraTreesClassifier,AdaBoostClassifier,BaggingClassifier,GradientBoostingClassifier
from imblearn.under_sampling import RandomUnderSampler
from imblearn.ensemble import BalancedBaggingClassifier, BalancedRandomForestClassifier
from collections import Counter
from sklearn.tree import DecisionTreeClassifier
from sklearn.datasets import make_classification
from evaluation import accuracy,f1_binary,f1_macro,f1_micro, auc_scores, f1_score
# from test_load_data import test_load_data
from ConcatenatTestLoad import test_load_data
# from feature_selection import select_feature
from feature_selection_test import feature_select
from sklearn.metrics import average_precision_score,matthews_corrcoef,recall_score,confusion_matrix,classification_report,roc_auc_score,auc,precision_recall_curve,accuracy_score,classification_report, roc_curve
from imblearn.ensemble import BalancedBaggingClassifier,RUSBoostClassifier,BalancedRandomForestClassifier
from imblearn.metrics import geometric_mean_score
from sklearn.inspection import permutation_importance
import matplotlib.pyplot as plt


# x,y,dataid=load_data()
x, y, dataid = test_load_data(dataid=1)
for index in range(len(y)): 
    if y[index]==0.0:
        y[index]=0.0    
    if y[index]==1.0:
        y[index]=1.0
print("x_shape:",x.shape)

print("y_shape:",y.shape)

# print("y_distribution:",Counter(y))

def get_config():
    config={}
    config["random_state"]=None
    config["max_layers"]=100
    config["early_stop_rounds"]=5
    config["if_stacking"]=False
    config["if_save_model"]=False
    # f1_binary,f1_macro,f1_micro,accuracy
    config["train_evaluation"]=f1_macro
    config["estimator_configs"]=[]
    config["estimator_configs"].append({"n_fold":10,"type":"RandomForestClassifier","n_estimators":100,"n_jobs":-1, "min_impurity_decrease": 1e-7})
    config["estimator_configs"].append({"n_fold":10,"type":"RandomForestClassifier","n_estimators":100,"n_jobs":-1, "min_impurity_decrease": 1e-7})
    # config["estimator_configs"].append({"n_fold":10,"type":"ExtraTreesClassifier","n_estimators":100,"n_jobs":-1, "min_impurity_decrease": 1e-7})
    config["estimator_configs"].append({"n_fold":10, "type": "ExtraTreesClassifier", "n_estimators": 100, "n_jobs": -1, "min_impurity_decrease": 1e-7})
    config["estimator_configs"].append({"n_fold":10, "type": "ExtraTreesClassifier", "n_estimators": 100, "n_jobs": -1, "min_impurity_decrease": 1e-7})
    config["output_layer_config"]=[]
    # ExtraTreesClassifier
    return config


def my_score_function(estimator, X, y_true):
    y_pred = estimator.predict(X)
    return accuracy_score(y_true, y_pred)

if __name__=="__main__":   
    config=get_config()  
    skf=RepeatedStratifiedKFold(n_splits=5,random_state=0,n_repeats=1)

    accuracys=[]
    aucs=[]
    f1s=[]
    auprs=[]
    mccs=[]
    recalls=[]
    gmeans=[]
    i=0
    # 初始化fpr和tpr
    fpr = np.linspace(0, 1, 101)
    tpr = np.zeros_like(fpr)
    fpr_tpr = []
    for train_id,test_id in skf.split(x,y):
        print("============{}-th cross validation============".format(i))
        x_train,x_test,y_train,y_test=x[train_id],x[test_id],y[train_id],y[test_id]
        index=feature_select(x_train,y_train,650)
        x_train=x_train[:,index]
        x_test=x_test[:,index]
        config=get_config()
        gc=gcForest(config)
        gc.fit(x_train,y_train)
        # calculate y_score
        y_pred=gc.predict(x_test)
        y_pred_prob=gc.predict_proba(x_test)

        """ 使用BaggingClassifier 作为gcForest的嵌入单元， 比较我们提出的模型的性能"""
        # clf = DecisionTreeClassifier()
        # bagging = BaggingClassifier(base_estimator=clf, n_estimators=10, max_samples=0.5, max_features=0.5)
        # bagging.fit(x_train, y_train)
        # y_pred = bagging.predict(x_test)
        # y_pred_prob = bagging.predict_proba(x_test)

        """使用BalancedRandomForestClassifier 作为gcForest的嵌入单元，比较我们提出模型的性能"""
        # x, y = make_classification(n_samples=1000, n_features=10, n_classes=2, weights=[0.1, 0.9], random_state=42)
        # brf = BalancedRandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced_subsample')
        # brf.fit(x_train, y_train)
        # y_pred = brf.predict(x_test)
        # y_pred_prob = brf.predict_proba(x_test)


        y_score=[]
        for item in y_pred_prob:
            y_score.append(item[1])
        y_score=np.array(y_score)
        fold_fpr, fold_tpr, _ = roc_curve(y_test, y_score, pos_label=2)
        new_tpr = np.interp(fpr, fold_fpr, fold_tpr)

        tpr += new_tpr
        tpr /= skf.get_n_splits()

        # all_fpr = [x[0] for x in fpr_tpr]
        # all_tpr = [x[1] for x in fpr_tpr]
        # lengths_fpr = [len(a) for a in all_fpr]
        # lengths_tpr = [len(a) for a in all_tpr]
        # if len(set(lengths_fpr)) > 1 or len(set(lengths_tpr)) > 1:
        #     raise ValueError("Not all fpr/tpr arrays have the same length")
        # avg_fpr = np.mean(all_fpr, axis=0)
        # avg_tpr = np.mean(all_tpr, axis=0)
        roc_auc = auc(fpr, tpr)
        roc_df = pd.DataFrame({'FPR': fpr, 'TPR': tpr})
        roc_df.to_csv('roc.csv', index=False)

        precision, recall, thresholds = precision_recall_curve(y_test, y_score, pos_label=2)
        aupr = auc(recall,precision)

        accuracy = accuracy_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred,average='binary')       
        recall = recall_score(y_test, y_pred,average="binary")
        mcc = matthews_corrcoef(y_test, y_pred)
        gmean= geometric_mean_score(y_test, y_pred,average='binary')
        auc_s = auc_scores(y_test, y_pred_prob[:, 1])
          
        f1s.append(f1)
        accuracys.append(accuracy)
        aucs.append(auc_s)
        auprs.append(aupr)
        recalls.append(recall)
        mccs.append(mcc)
        gmeans.append(gmean)    
        i+=1

        # # after trained model, permutation_importance offer feature importance
        # result = permutation_importance(gc, x_test, y_test, n_repeats=10, random_state=0, scoring=my_score_function)
        # sorted_idx = result.importances_mean.argsort()[-20:]
        # top_20_features = x_test.columns[sorted_idx]
        
    print("============training finished============")
    f1s=np.array(f1s)
    accs = np.array(accuracys)
    auprs=np.array(auprs)
    recalls=np.array(recalls)
    mccs=np.array(mccs)
    gmeans=np.array(gmeans)

    def print_mean_std(metric_name, values):
        mean = np.mean(values)
        std = np.std(values)
        print(f"{metric_name}: {mean:.4f} ± {std:.4f}")


    print("Data:", dataid)
    print_mean_std("accuracy", accs)
    print_mean_std("auc", aucs)
    print_mean_std("f1", f1s)
    print_mean_std("aupr", auprs)
    print_mean_std("recall", recalls)
    print_mean_std("mcc", mccs)
    print_mean_std("gmean", gmeans)
