"""
本段代码是将微生物分类注释丰度数据拆分成在各自的分类等级上，
将拆分后的数据适应 LEfse 的输入文件中的 taxt(分类)。
"""
import multiprocessing
import pandas as pd

meta_file = "DataMicrobiome/ASD/Metada.csv"
abundance_file = "DataMicrobiome/ASD/abundance.csv"

def get_feature_df(features):
    kingdom, phylum, cl, order, family, genus, species = [], [], [], [], [], [], []
    for f in features:

        # name = f.split("k__")[1].split("|p__")[0].replace(".", "")
        name = f.split("d__")[1].split(".p__")[0].replace(".", "")
        if "_unclassified" in name:
            name = 'unclassified_' + name.split("_unclassified")[0]
        kingdom.append("k__" + name)

        if "p__" in f:
            # name = f.split("p__")[1].split("|c__")[0].replace(".", "")
            name = f.split("p__")[1].split(".c__")[0].replace(".", "")
            if "_unclassified" in name:
                name = 'unclassified_' + name.split("_unclassified")[0]
            if name != "":
                phylum.append("p__" + name)
            else:
                phylum.append("p__")
        else:
            phylum.append("p__")

        if "c__" in f:
            # name = f.split("c__")[1].split("|o__")[0].replace(".", "")
            name = f.split("c__")[1].split(".o__")[0].replace(".", "")
            if "_unclassified" in name:
                name = 'unclassified_' + name.split("_unclassified")[0]
            if name != "":
                cl.append("c__" + name)
            else:
                cl.append("c__")
        else:
            cl.append("c__")

        if "o__" in f:
            # name = f.split("o__")[1].split("|f__")[0].replace(".", "")
            name = f.split("o__")[1].split(".f__")[0].replace(".", "")
            if "_unclassified" in name:
                name = 'unclassified_' + name.split("_unclassified")[0]
            if name != "":
                order.append("o__" + name)
            else:
                # order.append("NA")
                order.append("o__")
        else:
            order.append("o__")

        if "f__" in f:
            # name = f.split("f__")[1].split("|g__")[0].replace(".", "")
            name = f.split("f__")[1].split(".g__")[0].replace(".", "")
            if "_unclassified" in name:
                name = 'unclassified_' + name.split("_unclassified")[0]
            if name != "":
                family.append("f__" + name)
            else:
                family.append("f__")
        else:
            family.append("f__")

        if "g__" in f:
            # name = f.split("g__")[1].split("|s__")[0].replace(".", "")
            name = f.split("g__")[1].split(".s__")[0].replace(".", "")
            if "_unclassified" in name:
                name = 'unclassified_' + name.split("_unclassified")[0]
            if name != "":
                genus.append("g__" + name)
            else:
                genus.append("g__")
        else:
            genus.append("g__")

        if "s__" in f:
            name = f.split("s__")[1]
            if "_unclassified" in name:
                name = 'unclassified_' + name.split("_unclassified")[0]
            if name != "":
                species.append("s__" + name)
            else:
                species.append("s__")
        else:
            species.append("s__")

    if len(species) == 0:
        d = {'kingdom': kingdom, 'phylum': phylum, 'class': cl,
             'order': order, 'family': family, 'genus': genus}
        feature_df = pd.DataFrame(data=d)
        feature_df.index = feature_df['genus']
    else:
        d = {'kingdom': kingdom, 'phylum': phylum, 'class': cl,
             'order': order, 'family': family, 'genus': genus, 'species': species}
        feature_df = pd.DataFrame(data=d)
        feature_df.index = feature_df['species']
    return feature_df

metadata = pd.read_csv(meta_file)
abundance = pd.read_csv(abundance_file)
label = metadata["disease"]
# print("label ", label)
# n_feature = abundance.shape[1] - 1
# print(n_feature)
abundance = abundance.drop(abundance.columns[0], axis=1)
# print(abundance.head())
features = get_feature_df(abundance)
# print(features.head())
output_file = "DataMicrobiome/ASD/.tax.csv"
features.to_csv(output_file, index=False)

print("Saved in", output_file)