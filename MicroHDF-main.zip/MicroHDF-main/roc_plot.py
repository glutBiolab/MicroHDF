import numpy as np
# import seaborn as sns
import matplotlib.pyplot as plt

# imbalance dataset: ibd
with open('roccurve.txt', 'r') as file:
    lines = file.readlines()

tpr_o = []
fpr_o = []
tpr_t = []
fpr_t = []

for line in lines:
    values = line.strip().split()
    if len(values) == 2:
        if values[0].startswith('tpr_o'):
            tpr_o.append(float(values[1]))
        elif values[0].startswith('fpr_o'):
            fpr_o.append(float(values[1]))
        elif values[0].startswith('tpr_t'):
            tpr_t.append(float(values[1]))
        elif values[0].startswith('fpr_t'):
            fpr_t.append(float(values[1]))

models = ['GNPI', 'PopPhy-CNN','DeepMicro', 'MLPNN', 'CNN1D', 'DeepForest', 'MetaML', 'RF', 'SVM', 'LASSO', 'MicroHDF']
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))


for i, (tpr_i, fpr_i) in enumerate(zip(tpr_c, fpr_c)):
    tpr_i = np.insert(tpr_i, 0, 0)
    fpr_i = np.insert(fpr_i, 0, 0)
    auc = np.trapz(tpr_i, fpr_i)

    ax1.plot(fpr_i, tpr_i, label='{} (area={:.4f})'.format(models[i], auc))

ax1.plot([0, 1], [0, 1], 'k--')

ax1.set_xlim([-0.05, 1.0])
ax1.set_ylim([-0.05, 1.05])


ax1.set_xlabel('False Positive Rate')
ax1.set_ylabel('True Positive Rate')
ax1.set_title('Cirrhosis ROC Curve')
ax1.legend(loc="lower right", fontsize=8)
for i, (tpr_i, fpr_i) in enumerate(zip(tpr_t, fpr_t)):
    # Computer AUC (Area Under Curve)
    auc = np.trapz(tpr_i, fpr_i)

    ax2.plot(fpr_i, tpr_i, label='{} (area={:.4f})'.format(models[i], auc))

ax2.plot([0, 1], [0, 1], 'k--')
ax2.set_xlim([-0.05, 1.0])
ax2.set_ylim([-0.05, 1.05])
ax2.set_xlabel('False Positive Rate')
ax2.set_ylabel('True Positive Rate')
ax2.set_title('C-T2D ROC Curve')
ax2.legend(loc="lower right", fontsize=8)
# ax2.legend(fontsize='small', bbox_to_anchor=(0.5, -0.3), loc='upper center')

# plt.tight_layout()
plt.subplots_adjust(wspace=0.4)
plt.savefig('ROCcurve_balanceDataset.svg', format='svg')
plt.show()

